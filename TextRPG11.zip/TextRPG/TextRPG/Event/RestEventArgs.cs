﻿namespace TextRPG
{
    public class RestEventArgs
    {
        
    }
}
