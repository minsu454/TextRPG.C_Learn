﻿namespace TextRPG
{
    public class KillEnemyEventArgs
    {
        public string? Enemy { get; set; }
        public int Count { get; set; }
    }
}
