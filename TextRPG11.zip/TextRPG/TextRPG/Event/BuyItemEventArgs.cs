﻿namespace TextRPG
{
    public class BuyItemEventArgs
    {
        public string? Name { get; set; }
        public int Count { get; set; }
    }
}
