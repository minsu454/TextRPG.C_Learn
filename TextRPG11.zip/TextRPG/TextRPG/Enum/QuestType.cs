﻿namespace TextRPG
{
    /// <summary>
    /// 퀘스트 이름 타입
    /// </summary>
    public enum QuestType
    {
        None = 0,
        Test1,
        Test2,
        Test3,
    }
}
