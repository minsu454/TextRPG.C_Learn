﻿namespace TextRPG
{
    public enum QuestStateType
    {
        None = 0,           //아직안깸
        Doing = 1,          //퀘스트 받음
        Completed = 2,      //깼음
        Rewarded = 3,       //보상받음

    }
}