using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextRPG.Scene
{
    public class StoreScene_Armor : StoreScene
    {
        public override void Load()
        {
            Console.WriteLine("�� ����");

            ChooseWeapon();

            GameManager.Scene.CloseScene();
        }

        public void ChooseWeapon()
        {
            int input = Input.InputKey(4); Input.Selection(1, "��", "�ƴϿ�");

            Console.WriteLine("ö����\n�κ�\nõ��\n����");

            {
                Console.WriteLine("�����Ͻðڽ��ϱ�?");
                if (input == 1)
                {
                    Console.WriteLine("���Ű� �Ϸ�Ǿ����ϴ�.");
                    //GameManager.Item.ItemEquip = true;
                }
            }
        }
    }
}