﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextRPG.Scene
{
    public class StoreScene_Weapon : StoreScene
    {
        public override void Load()
        {
            Console.WriteLine("무기 상점");

            ChooseWeapon();

            GameManager.Scene.CloseScene();
        }

        public void ChooseWeapon() 
        {
            int input = Input.InputKey(4); Input.Selection(1, "예", "아니오");

            Console.WriteLine("강철검\n나무스태프\n목궁\n수리검");

            {
                Console.WriteLine("구매하시겠습니까?");
                if (input == 1)
                {
                    Console.WriteLine("구매가 완료되었습니다.");
                    //GameManager.Item.ItemEquip = true;
                }
            }
        }
    }
}
