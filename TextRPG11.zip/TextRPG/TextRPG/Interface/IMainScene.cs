﻿namespace TextRPG
{
    public interface IMainScene
    {
        int shiftCount { get { return shiftCount; } set { shiftCount = value; } }
    }
}
